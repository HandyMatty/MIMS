import{r as t}from"./index-D5m7brAQ.js";function c(){const[,e]=t.useReducer(r=>r+1,0);return e}export{c as u};
