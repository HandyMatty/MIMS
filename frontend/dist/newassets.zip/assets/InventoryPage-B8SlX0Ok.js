import{k as e,q as s}from"./index-BY-OqtzB.js";const r=()=>e.jsx("div",{className:"flex flex-col w-full h-auto p-8",children:e.jsx("div",{children:e.jsx(s,{})})});export{r as default};
