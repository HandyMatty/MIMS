import{aM as a,a6 as s,aN as c}from"./index-CoTjVTXu.js";function n(r,t,e){return t=s(t),a(r,c()?Reflect.construct(t,e||[],s(r).constructor):t.apply(r,e))}export{n as _};
