import{bo as s,am as o,bp as c}from"./index-DN6_br7R.js";function n(r,t,e){return t=o(t),s(r,c()?Reflect.construct(t,e||[],o(r).constructor):t.apply(r,e))}export{n as _};
