import{k as s,s as e}from"./index-DUYyvjBV.js";const n=()=>s.jsx("div",{className:"container max-w-full",children:s.jsx("div",{className:"mt-5",children:s.jsx(e,{})})});export{n as default};
