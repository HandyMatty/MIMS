import{aL as a,a4 as s,aM as c}from"./index-CvNWCSBk.js";function n(r,t,e){return t=s(t),a(r,c()?Reflect.construct(t,e||[],s(r).constructor):t.apply(r,e))}export{n as _};
